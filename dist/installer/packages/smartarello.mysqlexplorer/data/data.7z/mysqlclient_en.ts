<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>UI::Session::EditSessionWindow</name>
    <message>
        <location filename="UI/Session/EditSessionWindow.cpp" line="37"/>
        <source>&amp;Connection name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="UI/Session/EditSessionWindow.cpp" line="38"/>
        <source>&amp;Hostname / IP:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="UI/Session/EditSessionWindow.cpp" line="39"/>
        <source>&amp;User:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="UI/Session/EditSessionWindow.cpp" line="40"/>
        <source>&amp;Password:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="UI/Session/EditSessionWindow.cpp" line="41"/>
        <source>&amp;Port:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
